/*
 Name        : header.h
 Author      : De Padova Antonio
 Version     :
 Copyright   :
 Description : Header file for Calculator with UDP protocol
 */
#ifndef HEADER_H_
#define HEADER_H_

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#define MAX_CLIENTS 5 // Maximum number of allowed clients
#define BUFFER_SIZE 1024 // Size of the buffer for data transmission

void ClearWinSock()
{
	#if defined WIN32
		WSACleanup();
	#endif
}

#endif /* HEADER_H_ */
